package main

//Record 存放请求数据文件的交易记录
type Record struct {
	RecordNumber string `json:"RecordNumber"` //资源文件请求记录的序号

	// DSC          Member        `json:"DSC"`          //数据资源消费者
	CID              string `json:"CID"`              //消费者ID
	CIPAdress        string `json:"CIPAdress"`        //消费者IP地址
	CEndofMembership string `json:"CEndofMembership"` //消费者会员资格的结束时间
	COrgName         string `json:"COrgName"`         //消费者所属组织名

	Time string `json:"Time"` //消费者发出申请的时间
	Path string `json:"Path"` //数据资源文件传输的路径

	// File         DataFile      `json:"File"`         //数据资源文件基本信息
	FileName   string `json:"FileName"`   //数据资源文件名
	PID        string `json:"PID"`        //提供者ID
	PIPAdress  string `json:"PIPAdress"`  //提供者IP地址
	POrgName   string `json:"POrgName"`   //提供者所属组织名
	ModifyTime string `json:"ModifyTime"` //文件修改时间

	// Histories []HistoryItem //详细历史记录
}

// //Member 存放用户基本信息
// type Member struct {
// 	ID              string `json:"ID"`              //用户ID
// 	IPAdress        string `json:"IPAdress"`        //用户IP地址
// 	EndofMembership string `json:"EndofMembership"` //用户会员资格的结束时间
// 	OrgName         string `json:"OrgName"`         //所属组织名
// }

//DataFile 上传文件时，文件的基本信息
type DataFile struct {
	FileName   string `json:"FileName"`   //数据资源文件名
	ID         string `json:"ID"`         //提供者ID
	IPAdress   string `json:"IPAdress"`   //提供者IP地址
	OrgName    string `json:"OrgName"`    //提供者所属组织名
	ModifyTime string `json:"ModifyTime"` //修改时间
}

// //HistoryItem 详细历史记录
// type HistoryItem struct {
// 	TxID   string //交易编号
// 	Record Record //当前Record的详细历史记录
// }
