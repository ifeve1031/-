package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

//record相关的链码

//PutRecord 写入记录,实现将指定的对象序列化后保存至分类账本中
func PutRecord(stub shim.ChaincodeStubInterface, rec Record) ([]byte, bool) {
	r, err := json.Marshal(rec)
	if err != nil {
		return nil, false
	}

	err = stub.PutState(rec.RecordNumber, r)
	if err != nil {
		return nil, false
	}

	return r, true
}

// GetRecInfo 根据记录序号查询信息状态
// args: recordNumber
func GetRecInfo(stub shim.ChaincodeStubInterface, recNumber string) (Record, bool) {
	var rec Record
	// 根据记录序号查询信息状态
	b, err := stub.GetState(recNumber)
	if err != nil {
		return rec, false
	}

	if b == nil {
		return rec, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(b, &rec)
	if err != nil {
		return rec, false
	}

	// 返回结果
	return rec, true
}

// 根据指定的查询字符串实现富查询
func getRecByQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	// 富查询的返回结果可能为多条 所以这里返回的是一个迭代器 需要我们进一步的处理来获取需要的结果
	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}

		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		bArrayMemberAlreadyWritten = true
	}

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil

}

//接收对象并调用 PutRecord 函数实现保存状态的功能
func (t *DataChaincode) addRecord(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	//两个参数前一个是record，后一个是事件ID
	if len(args) != 2 {
		return shim.Error("给定的参数个数不符合要求")
	}

	var rec Record
	err := json.Unmarshal([]byte(args[0]), &rec)
	if err != nil {
		return shim.Error("反序列化信息时发生错误")
	}

	//判断会员资格是否过期
	now := time.Now()
	end, _ := strconv.Atoi(rec.CEndofMembership)
	if end < now.Year() {
		return shim.Error("会员资格已过期")
	}

	// 查重: 记录序号必须唯一
	_, exist := GetRecInfo(stub, rec.RecordNumber)
	if exist {
		return shim.Error("要添加的记录序号已存在")
	}

	_, bl := PutRecord(stub, rec)
	if !bl {
		return shim.Error("保存信息时发生错误")
	}

	err = stub.SetEvent(args[1], []byte{})
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte("信息添加成功"))
}

// 根据记录编号查询文件交易记录
// args: RecNumber
func (t *DataChaincode) getRecordByRecNumber(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	r, err := stub.GetState(args[0])
	fmt.Println(r)
	if err != nil {
		return shim.Error("根据记录编号查询文件交易记录失败")
	}

	if r == nil {
		return shim.Error("根据记录编号有查询到相关的信息")
	}

	// 对查询到的状态进行反序列化
	var rec Record
	err = json.Unmarshal(r, &rec)
	if err != nil {
		return shim.Error("反序列化rec信息失败")
	}
	result, err := json.Marshal(rec)
	if err != nil {
		return shim.Error("序列化rec信息时发生错误")
	}
	return shim.Success(result)
}

// 根据文件提供者ID查询文件交易记录
// args: File.ID
func (t *DataChaincode) getRecordByProviderID(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	id := args[0]

	// 拼装CouchDB所需要的查询字符串(是标准的一个JSON串)
	queryString := fmt.Sprintf("{\"selector\":{ \"PID\":\"%s\"}}", id) //这里不确定

	// 查询数据
	result, err := getRecByQueryString(stub, queryString)
	if err != nil {
		return shim.Error("根据文件提供者ID查询文件交易记录时发生错误")
	}
	if result == nil {
		return shim.Error("根据文件提供者ID没有查询到相关的信息")
	}
	return shim.Success(result)
}

// 根据文件使用者ID查询文件交易记录
// args: DSC.ID
func (t *DataChaincode) getRecordByConsumerID(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	id := args[0]

	// 拼装CouchDB所需要的查询字符串(是标准的一个JSON串)
	queryString := fmt.Sprintf("{\"selector\":{ \"CID\":\"%s\"}}", id) //这里不确定

	// 查询数据
	result, err := getRecByQueryString(stub, queryString)
	if err != nil {
		return shim.Error("根据使用者ID查询文件交易记录时发生错误")
	}
	if result == nil {
		return shim.Error("根据文件使用者ID没有查询到相关的信息")
	}
	return shim.Success(result)
}

// 根据文件名查询文件交易记录
// args: File.Filename
func (t *DataChaincode) getRecordByFileName(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	filename := args[0]

	// 拼装CouchDB所需要的查询字符串(是标准的一个JSON串)
	queryString := fmt.Sprintf("{\"selector\":{ \"FileName\":\"%s\"}}", filename) //这里不确定

	// 查询数据
	result, err := getRecByQueryString(stub, queryString)
	if err != nil {
		return shim.Error("根据文件名查询文件交易记录时发生错误")
	}
	if result == nil {
		return shim.Error("根据文件文件名没有查询到相关的信息")
	}
	return shim.Success(result)
}
