package main

import (
	"fmt"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

//DataChaincode ...
type DataChaincode struct {
}

//Init ...
func (t *DataChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {

	return shim.Success(nil)
}

//Invoke ...
func (t *DataChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	// 获取用户意图
	fun, args := stub.GetFunctionAndParameters()

	if fun == "addRecord" {
		return t.addRecord(stub, args) //交易正确性被验证后，上传使用文件交易记录
	} else if fun == "addFile" {
		return t.addFile(stub, args) //鉴权后，上传数据文件
	} else if fun == "delFile" {
		return t.delFile(stub, args) //鉴权后，删除指定数据文件
	} else if fun == "updateFile" {
		return t.updateFile(stub, args) //鉴权后，上传新的数据文件
	} else if fun == "getRecordByRecNumber" {
		return t.getRecordByRecNumber(stub, args) //通过记录编号获取使用文件交易记录
	} else if fun == "getRecordByProviderID" {
		return t.getRecordByProviderID(stub, args) //通过文件提供者ID获取使用文件交易记录
	} else if fun == "getRecordByConsumerID" {
		return t.getRecordByConsumerID(stub, args) //通过文件使用者ID获取使用文件交易记录
	} else if fun == "getRecordByFileName" {
		return t.getRecordByFileName(stub, args) //通过文件名获取使用文件交易记录
	} else if fun == "getFileByFileName" {
		return t.getFileByFileName(stub, args) //通过文件名获取提供文件信息
	} else if fun == "getFileByProviderID" {
		return t.getFileByProviderID(stub, args) //通过文件提供者ID获取提供文件信息
	} else if fun == "set" {
		return t.set(stub, args)
	}

	return shim.Error("指定的函数名称错误")

}

func main() {
	err := shim.Start(new(DataChaincode))
	if err != nil {
		fmt.Printf("启动DataChaincode时发生错误: %s", err)
	}
}
