package main

import (
	"bytes"
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

//文件操作相关的链码

func (t *DataChaincode) set(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 2 {
		return shim.Error("1")
	}

	err := stub.PutState(args[0], []byte(args[1]))
	if err != nil {
		return shim.Error("2")
	}
	return shim.Success([]byte("信息添加成功"))

}

//PutFile 写入要上传的文件信息,实现将指定的对象序列化后保存至分类账本中
func PutFile(stub shim.ChaincodeStubInterface, file DataFile) ([]byte, bool) {
	f, err := json.Marshal(file)
	if err != nil {
		return nil, false
	}

	err = stub.PutState(file.FileName, f)
	if err != nil {
		return nil, false
	}

	return f, true
}

// GetFileInfo 根据文件名查询信息状态
// args: Filename
func GetFileInfo(stub shim.ChaincodeStubInterface, filename string) (DataFile, bool) {
	var file DataFile
	// 根据记录序号查询信息状态
	f, err := stub.GetState(filename)
	if err != nil {
		return file, false
	}

	if f == nil {
		return file, false
	}

	// 对查询到的状态进行反序列化
	err = json.Unmarshal(f, &file)
	if err != nil {
		return file, false
	}

	// 返回结果
	return file, true
}

// 根据指定的查询字符串实现富查询
func getFileByQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	// 富查询的返回结果可能为多条 所以这里返回的是一个迭代器 需要我们进一步的处理来获取需要的结果
	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}

		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		bArrayMemberAlreadyWritten = true
	}

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil

}

//接收对象并调用 PutFile 函数实现保存状态的功能
func (t *DataChaincode) addFile(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	//两个参数前一个是file，后一个是事件ID
	if len(args) != 2 {
		return shim.Error("给定的参数个数不符合要求")
	}
	var file DataFile
	err := json.Unmarshal([]byte(args[0]), &file)
	if err != nil {
		return shim.Error("反序列化信息时发生错误")
	}

	// 查重: 文件名必须唯一
	_, exist := GetFileInfo(stub, file.FileName)
	if exist {
		return shim.Error("要添加的文件名已存在")
	}

	_, bl := PutFile(stub, file)
	if !bl {
		return shim.Error("保存信息时发生错误")
	}

	err = stub.SetEvent(args[1], []byte{})
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte("信息添加成功"))
}

//通过文件名获取文件信息
func (t *DataChaincode) getFileByFileName(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}

	f, err := stub.GetState(args[0])
	if err != nil {
		return shim.Error("根据文件名获取文件信息失败")
	}

	if f == nil {
		return shim.Error("根据文件名没有查询到相关的信息")
	}

	// 对查询到的状态进行反序列化
	var file DataFile
	err = json.Unmarshal(f, &file)
	if err != nil {
		return shim.Error("反序列化file信息失败")
	}
	result, err := json.Marshal(file)
	if err != nil {
		return shim.Error("序列化file信息时发生错误")
	}
	return shim.Success(result)
}

// 根据文件提供者ID查询文件信息
// args: File.ID
func (t *DataChaincode) getFileByProviderID(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	id := args[0]

	// 拼装CouchDB所需要的查询字符串(是标准的一个JSON串)
	queryString := fmt.Sprintf("{\"selector\":{ \"ID\":\"%s\"}}", id) //这里不确定

	// 查询数据
	result, err := getRecByQueryString(stub, queryString)
	if err != nil {
		return shim.Error("根据文件提供者ID查询文件信息时发生错误")
	}
	if result == nil {
		return shim.Error("根据文件提供者ID没有查询到相关的信息")
	}
	return shim.Success(result)
}

//删除文件
func (t *DataChaincode) delFile(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("给定的参数个数不符合要求")
	}
	err := stub.DelState(args[0])
	if err != nil {
		return shim.Error("delete error")
	}
	return shim.Success([]byte("delete success"))

}

//修改文件
func (t *DataChaincode) updateFile(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	// if len(args) != 3 {
	// 	return shim.Error("给定的参数个数不符合要求")
	// }
	// a := []string{args[0]}
	// b := []string{args[1], args[2]}
	// t.delFile(stub, a)
	// return t.addFile(stub, b)
	//两个参数前一个是file，后一个是事件ID
	if len(args) != 2 {
		return shim.Error("给定的参数个数不符合要求")
	}
	var file DataFile
	err := json.Unmarshal([]byte(args[0]), &file)
	if err != nil {
		return shim.Error("反序列化信息时发生错误")
	}

	// 查重: 文件名必须唯一
	_, exist := GetFileInfo(stub, file.FileName)
	if !exist {
		return shim.Error("要更新的文件不存在,请直接上传")
	}

	_, bl := PutFile(stub, file)
	if !bl {
		return shim.Error("保存信息时发生错误")
	}

	err = stub.SetEvent(args[1], []byte{})
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte("信息添加成功"))
}
