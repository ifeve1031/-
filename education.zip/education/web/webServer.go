package web

import (
	"fmt"
	"net/http"

	"github.com/kongyixueyuan.com/education/web/controller"
)

//WebStart 启动Web服务并指定路由信息
func WebStart(app controller.Application) {

	fs := http.FileServer(http.Dir("web/static"))
	http.Handle("/static/", http.StripPrefix("/static/", fs))

	// 指定路由信息(匹配请求)
	http.HandleFunc("/", app.LoginView) //这个是什么
	http.HandleFunc("/login", app.Login)
	http.HandleFunc("/loginout", app.LoginOut)

	http.HandleFunc("/index", app.Index)

	http.HandleFunc("/addFileInfo", app.AddFileShow)
	http.HandleFunc("/addFile", app.AddFile)

	http.HandleFunc("/queryFilePage", app.QueryFilePage)
	http.HandleFunc("/queryFile", app.FindFileByFileName)

	http.HandleFunc("/queryFilePage2", app.QueryFilePage2)
	http.HandleFunc("/queryFile2", app.FindFileByProviderID)

	http.HandleFunc("/updateFilePage", app.UpdateFilePage)
	http.HandleFunc("/updateFile", app.UpdateFile)

	http.HandleFunc("/deleteFilePage", app.DeleteFilePage)
	http.HandleFunc("/deleteFile", app.DeleteFile)

	// http.HandleFunc("/addRecInfo", app.AddRecShow)
	http.HandleFunc("/addRec", app.AddRec)

	//这个注意，到底对不对
	http.HandleFunc("/findRecByRecordNumber", app.FindRecByRecordNumber)

	http.HandleFunc("/queryRecPage", app.QueryRecPage)
	http.HandleFunc("/queryRec", app.FindRecByFileName)

	http.HandleFunc("/queryRecPage2", app.QueryRecPage2)
	http.HandleFunc("/queryRec2", app.FindRecByCID)

	http.HandleFunc("/queryRecPage3", app.QueryRecPage3)
	http.HandleFunc("/queryRec3", app.FindRecByPID)

	fmt.Println("启动Web服务, 监听端口号为: 9000")
	err := http.ListenAndServe(":9000", nil)
	if err != nil {
		fmt.Printf("Web服务启动失败: %v", err)
	}
}
