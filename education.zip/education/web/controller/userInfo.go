package controller

import "github.com/kongyixueyuan.com/education/service"

//Application ...
type Application struct {
	Setup *service.ServiceSetup
}

//User 用户信息
type User struct {
	LoginName       string
	Password        string
	IsAdmin         string
	Org             string
	EndofMembership int
}

var users []User

func init() {
	//管理员alice
	alice := User{LoginName: "alice", Password: "123456", IsAdmin: "T", Org: "NJUPT", EndofMembership: 2035}
	//普通用户bob
	bob := User{LoginName: "bob", Password: "123456", IsAdmin: "F", Org: "CUPT", EndofMembership: 2035}

	users = append(users, alice)
	users = append(users, bob)

}

func isAdmin(cuser User) bool {
	if cuser.IsAdmin == "T" {
		return true
	}
	return false
}
