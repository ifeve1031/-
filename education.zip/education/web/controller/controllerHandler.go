package controller

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/kongyixueyuan.com/education/service"
)

var cuser User

//LoginView 登录界面 1.login.html
func (app *Application) LoginView(w http.ResponseWriter, r *http.Request) {

	ShowView(w, r, "login.html", nil)
}

//Index 目录，是登陆后显示的主要界面，可以选择查询记录或者文件等功能 2.index.html
func (app *Application) Index(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "index.html", data)
}

//Login 用户登录
func (app *Application) Login(w http.ResponseWriter, r *http.Request) {
	loginName := r.FormValue("loginName")
	password := r.FormValue("password")

	var flag bool
	for _, user := range users {
		if user.LoginName == loginName && user.Password == password {
			cuser = user
			flag = true
			break
		}
	}

	data := &struct {
		CurrentUser User
		Flag        bool
	}{
		CurrentUser: cuser,
		Flag:        false,
	}

	if flag {
		// 登录成功
		ShowView(w, r, "index.html", data)
	} else {
		// 登录失败
		data.Flag = true
		data.CurrentUser.LoginName = loginName
		ShowView(w, r, "login.html", data)
	}
}

//LoginOut 用户登出
func (app *Application) LoginOut(w http.ResponseWriter, r *http.Request) {
	cuser = User{}
	ShowView(w, r, "login.html", nil)
}

//AddFileShow 显示添加信息页面 3.addFile.html
func (app *Application) AddFileShow(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "addFile.html", data)
}

//AddFile 添加信息
func (app *Application) AddFile(w http.ResponseWriter, r *http.Request) {

	file := service.DataFile{
		FileName:   r.FormValue("FileName"),
		ID:         r.FormValue("ID"),
		IPAdress:   r.FormValue("IPAdress"),
		OrgName:    r.FormValue("OrgName"),
		ModifyTime: r.FormValue("ModifyTime"),
	}
	FileName := file.FileName
	flag := true
	result, err := app.Setup.FindFileByFileName(FileName)
	var filecheck = service.DataFile{}
	json.Unmarshal(result, &filecheck)
	if err != nil {
		fmt.Println(err)
	}
	if filecheck.FileName == FileName {
		flag = false
		fmt.Println("该文件已存在，如需重新上传请使用“修改文件”功能")
	}
	if flag == true {
		app.Setup.SaveFile(file)

		r.Form.Set("FileName", file.FileName)
		app.FindFileByFileName(w, r)
	} else {
		ShowView(w, r, "fail.html", nil)
	}

}

//QueryFilePage 根据文件名查询文件的页面 4.query.html
func (app *Application) QueryFilePage(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "query.html", data)
}

//FindFileByFileName 根据文件名查询文件
func (app *Application) FindFileByFileName(w http.ResponseWriter, r *http.Request) {
	FileName := r.FormValue("FileName")
	result, err := app.Setup.FindFileByFileName(FileName)
	var file = service.DataFile{}
	json.Unmarshal(result, &file)

	fmt.Println("根据文件名查询文件成功：")
	fmt.Println(file)

	data := &struct {
		DataFile    service.DataFile
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		DataFile:    file,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     false,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	//6.queryFileResult.html
	ShowView(w, r, "queryFileResult.html", data)
}

//QueryFilePage2 根据提供者id获取文件的页面 7.query2.html
func (app *Application) QueryFilePage2(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "query2.html", data)
}

//FindFileByProviderID 根据提供者id查询文件
func (app *Application) FindFileByProviderID(w http.ResponseWriter, r *http.Request) {
	id := r.FormValue("ID")
	result, err := app.Setup.FindFileByProviderID(id)
	var file = service.DataFile{}
	json.Unmarshal(result, &file)

	fmt.Println("根据文件名查询文件成功：")
	fmt.Println(file)

	data := &struct {
		DataFile    service.DataFile
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		DataFile:    file,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     true,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	ShowView(w, r, "queryFileResult.html", data)
}

//UpdateFilePage 上传新文件界面 8.pdateFile.html
func (app *Application) UpdateFilePage(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}

	ShowView(w, r, "updateFile.html", data)
}

//UpdateFile 上传新文件
func (app *Application) UpdateFile(w http.ResponseWriter, r *http.Request) {
	file := service.DataFile{
		FileName:   r.FormValue("FileName"),
		ID:         r.FormValue("ID"),
		IPAdress:   r.FormValue("IPAdress"),
		OrgName:    r.FormValue("OrgName"),
		ModifyTime: r.FormValue("ModifyTime"),
	}

	app.Setup.UpdateFile(file)

	r.Form.Set("FileName", file.FileName)
	app.FindFileByFileName(w, r)
}

//DeleteFilePage 删除文件的界面 9.deleteFile.html
func (app *Application) DeleteFilePage(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}

	ShowView(w, r, "deleteFile.html", data)
}

//DeleteFile 删除文件(存疑)
func (app *Application) DeleteFile(w http.ResponseWriter, r *http.Request) {
	file := service.DataFile{
		FileName:   r.FormValue("FileName"),
		ID:         r.FormValue("ID"),
		IPAdress:   r.FormValue("IPAdress"),
		OrgName:    r.FormValue("OrgName"),
		ModifyTime: r.FormValue("ModifyTime"),
	}

	app.Setup.DeleteFile(file.FileName)

	r.Form.Set("FileName", file.FileName)
	app.FindFileByFileName(w, r)

}

// //AddRecShow 显示申请使用数据文件页面 10.addRec.html
// func (app *Application) AddRecShow(w http.ResponseWriter, r *http.Request) {
// 	data := &struct {
// 		CurrentUser User
// 		Msg         string
// 		Flag        bool
// 	}{
// 		CurrentUser: cuser,
// 		Msg:         "",
// 		Flag:        false,
// 	}
// 	ShowView(w, r, "addRec.html", data)
// }

//AddRec 添加信息
func (app *Application) AddRec(w http.ResponseWriter, r *http.Request) {

	rec := service.Record{
		RecordNumber:     r.FormValue("RecordNumber"),
		CID:              r.FormValue("CID"),
		CIPAdress:        r.FormValue("CIPAdress"),
		CEndofMembership: r.FormValue("CEndofMembership"),
		COrgName:         r.FormValue("COrgName"),
		Time:             r.FormValue("Time"),
		Path:             r.FormValue("Path"),
		FileName:         r.FormValue("FileName"),
		PID:              r.FormValue("PID"),
		PIPAdress:        r.FormValue("PIPAdress"),
		POrgName:         r.FormValue("POrgName"),
		ModifyTime:       r.FormValue("ModifyTime"),
	}

	app.Setup.SaveRecord(rec)

	r.Form.Set("RecordNumber", rec.RecordNumber)
	app.FindRecByRecordNumber(w, r)
}

//FindRecByRecordNumber 根据记录编号查询交易
func (app *Application) FindRecByRecordNumber(w http.ResponseWriter, r *http.Request) {
	RecordNumber := r.FormValue("RecordNumber")
	result, err := app.Setup.FindRecByRecNumber(RecordNumber)
	var rec = service.Record{}
	json.Unmarshal(result, &rec)

	fmt.Println("根据记录编号查询交易成功：")
	fmt.Println(rec)

	data := &struct {
		Record      service.Record
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		Record:      rec,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     false,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	//12.queryFileResult.html
	ShowView(w, r, "queryRecResult.html", data)
}

// //QueryRecPage 根据文件名查询交易 11.queryRec.html
// func (app *Application) QueryRecPage(w http.ResponseWriter, r *http.Request) {
// 	data := &struct {
// 		CurrentUser User
// 		Msg         string
// 		Flag        bool
// 	}{
// 		CurrentUser: cuser,
// 		Msg:         "",
// 		Flag:        false,
// 	}
// 	ShowView(w, r, "queryRec.html", data)
// }

// //FindRecByFileName 根据文件名查询交易
// func (app *Application) FindRecByFileName(w http.ResponseWriter, r *http.Request) {
// 	FileName := r.FormValue("FileName")
// 	result, err := app.Setup.FindRecByFileName(FileName)
// 	var rec service.Record
// 	err = json.Unmarshal(result, &rec)
// 	fmt.Println(err)
// 	fmt.Println(result)

// 	fmt.Println("根据文件名查询交易成功：")
// 	fmt.Println(rec)

// 	data := &struct {
// 		Record      service.Record
// 		CurrentUser User
// 		Msg         string
// 		Flag        bool
// 		History     bool
// 	}{
// 		Record:      rec,
// 		CurrentUser: cuser,
// 		Msg:         "",
// 		Flag:        false,
// 		History:     false,
// 	}

// 	if err != nil {
// 		data.Msg = err.Error()
// 		data.Flag = true
// 	}

// 	ShowView(w, r, "queryRecResult.html", data)
// }

//QueryRecPage 根据文件名查询交易 11.queryRec.html
func (app *Application) QueryRecPage(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "queryRec.html", data)
}

//FindRecByFileName 根据文件名查询交易
func (app *Application) FindRecByFileName(w http.ResponseWriter, r *http.Request) {
	filename := r.FormValue("FileName")
	result, err := app.Setup.FindRecByFileName(filename)
	var rec = service.Record{}
	json.Unmarshal(result[:len(result)-102], &rec) //232

	fmt.Println("根据文件名查询交易成功：")
	fmt.Println(rec)

	data := &struct {
		Record      service.Record
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		Record:      rec,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     false,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	ShowView(w, r, "queryRecResult.html", data)
}

//QueryRecPage2 根据消费者id查询交易 13.queryRec2.html
func (app *Application) QueryRecPage2(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "queryRec2.html", data)
}

//FindRecByCID 根据消费者id查询交易
func (app *Application) FindRecByCID(w http.ResponseWriter, r *http.Request) {
	cid := r.FormValue("CID")
	result, err := app.Setup.FindRecByConsumerID(cid)
	var rec = service.Record{}
	json.Unmarshal(result, &rec)

	fmt.Println("根据消费者id查询交易成功：")
	fmt.Println(rec)

	data := &struct {
		Record      service.Record
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		Record:      rec,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     false,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	ShowView(w, r, "queryRecResult.html", data)
}

//QueryRecPage3 根据提供者id查询交易 14.queryRec3.html
func (app *Application) QueryRecPage3(w http.ResponseWriter, r *http.Request) {
	data := &struct {
		CurrentUser User
		Msg         string
		Flag        bool
	}{
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
	}
	ShowView(w, r, "queryRec3.html", data)
}

//FindRecByPID 根据提供者id查询交易
func (app *Application) FindRecByPID(w http.ResponseWriter, r *http.Request) {
	pid := r.FormValue("PID")
	result, err := app.Setup.FindRecByProviderID(pid)
	var rec = service.Record{}
	json.Unmarshal(result, &rec)

	fmt.Println("根据提供者id查询交易成功：")
	fmt.Println(rec)

	data := &struct {
		Record      service.Record
		CurrentUser User
		Msg         string
		Flag        bool
		History     bool
	}{
		Record:      rec,
		CurrentUser: cuser,
		Msg:         "",
		Flag:        false,
		History:     false,
	}

	if err != nil {
		data.Msg = err.Error()
		data.Flag = true
	}

	ShowView(w, r, "queryRecResult.html", data)
}
