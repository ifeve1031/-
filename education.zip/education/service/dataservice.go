package service

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-sdk-go/pkg/client/channel"
)

//SaveRecord 写入交易
func (t *ServiceSetup) SaveRecord(rec Record) (string, error) {

	eventID := "eventAddRec"
	reg, notifier := regitserEvent(t.Client, t.ChaincodeID, eventID)
	defer t.Client.UnregisterChaincodeEvent(reg)

	// 将edu对象序列化成为字节数组
	b, err := json.Marshal(rec)
	if err != nil {
		return "", fmt.Errorf("指定的record对象序列化时发生错误")
	}

	req := channel.Request{
		ChaincodeID: t.ChaincodeID,
		Fcn:         "addRecord",
		Args:        [][]byte{b, []byte(eventID)},
	}
	respone, err := t.Client.Execute(req)
	if err != nil {
		return "", err
	}

	err = eventResult(notifier, eventID)
	if err != nil {
		return "", err
	}

	return string(respone.TransactionID), nil
}

//FindRecByRecNumber 根据记录编号获取交易记录
func (t *ServiceSetup) FindRecByRecNumber(RecordNumber string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getRecordByRecNumber", Args: [][]byte{[]byte(RecordNumber)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//FindRecByProviderID 根据提供者id获取交易记录
func (t *ServiceSetup) FindRecByProviderID(id string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getRecordByProviderID", Args: [][]byte{[]byte(id)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//FindRecByConsumerID 根据消费者id获取交易记录
func (t *ServiceSetup) FindRecByConsumerID(id string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getRecordByConsumerID", Args: [][]byte{[]byte(id)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//FindRecByFileName 根据文件名获取交易记录
func (t *ServiceSetup) FindRecByFileName(fileName string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getRecordByFileName", Args: [][]byte{[]byte(fileName)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//交易记录链码测试结束

//SaveFile 写入文件
func (t *ServiceSetup) SaveFile(file DataFile) (string, error) {

	eventID := "eventAddFile"
	reg, notifier := regitserEvent(t.Client, t.ChaincodeID, eventID)
	defer t.Client.UnregisterChaincodeEvent(reg)

	// 将edu对象序列化成为字节数组
	b, err := json.Marshal(file)
	if err != nil {
		return "", fmt.Errorf("指定的DataFile对象序列化时发生错误")
	}

	req := channel.Request{
		ChaincodeID: t.ChaincodeID,
		Fcn:         "addFile",
		Args:        [][]byte{b, []byte(eventID)},
	}
	respone, err := t.Client.Execute(req)
	if err != nil {
		return "", err
	}

	err = eventResult(notifier, eventID)
	if err != nil {
		return "", err
	}

	return string(respone.TransactionID), nil
}

//FindFileByFileName 根据文件名获取文件
func (t *ServiceSetup) FindFileByFileName(filename string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getFileByFileName", Args: [][]byte{[]byte(filename)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//FindFileByProviderID 根据提供者id获取文件
func (t *ServiceSetup) FindFileByProviderID(id string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "getFileByProviderID", Args: [][]byte{[]byte(id)}}
	respone, err := t.Client.Query(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//DeleteFile 删除文件
func (t *ServiceSetup) DeleteFile(filename string) ([]byte, error) {

	req := channel.Request{ChaincodeID: t.ChaincodeID, Fcn: "delFile", Args: [][]byte{[]byte(filename)}}
	respone, err := t.Client.Execute(req)
	if err != nil {
		return []byte{0x00}, err
	}

	return respone.Payload, nil
}

//UpdateFile 更新文件
func (t *ServiceSetup) UpdateFile(file DataFile) (string, error) {

	eventID := "eventUpdateFile"
	reg, notifier := regitserEvent(t.Client, t.ChaincodeID, eventID)
	defer t.Client.UnregisterChaincodeEvent(reg)

	// 将edu对象序列化成为字节数组
	b, err := json.Marshal(file)
	if err != nil {
		return "", fmt.Errorf("指定的DataFile对象序列化时发生错误")
	}

	req := channel.Request{
		ChaincodeID: t.ChaincodeID,
		Fcn:         "updateFile",
		Args:        [][]byte{b, []byte(eventID)},
	}
	respone, err := t.Client.Execute(req)
	if err != nil {
		return "", err
	}

	err = eventResult(notifier, eventID)
	if err != nil {
		return "", err
	}

	return string(respone.TransactionID), nil
}
