package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/kongyixueyuan.com/education/sdkInit"
	"github.com/kongyixueyuan.com/education/service"
	"github.com/kongyixueyuan.com/education/web"
	"github.com/kongyixueyuan.com/education/web/controller"
)

const (
	//配置文件,给应用程序所使用的 Fabric-SDK-Go 配置相关参数及 Fabric 组件的通信地址
	configFile = "config.yaml"
	//判断是否已经实例化
	initialized = false
	//DataCC ...
	DataCC = "simplecc"
)

func main() {
	//在fabricInitInfo定义的结构体
	initInfo := &sdkInit.InitInfo{

		ChannelID: "kevinkongyixueyuan",
		//os.Getenv("GOPATH")用于读取环境变量
		//ChannelConfig: "/home/niqinyin/go" + "/src/github.com/kongyixueyuan.com/kongyixueyuan/fixtures/artifacts/channel.tx",
		ChannelConfig: os.Getenv("GOPATH") + "/src/github.com/kongyixueyuan.com/education/fixtures/artifacts/channel.tx",

		OrgAdmin:       "Admin",
		OrgName:        "Org1",
		OrdererOrgName: "orderer.kevin.kongyixueyuan.com",

		//链码
		ChaincodeID:     DataCC,
		ChaincodeGoPath: os.Getenv("GOPATH"),
		ChaincodePath:   "github.com/kongyixueyuan.com/education/chaincode/",
		UserName:        "User1",
	}

	sdk, err := sdkInit.SetupSDK(configFile, initialized)
	if err != nil {
		fmt.Printf(err.Error())
		return
	}

	//Go语言中的defer语句会将其后面跟随的语句进行延迟处理。
	//在defer归属的函数即将返回时，将延迟处理的语句按defer定义的逆序进行执行
	//Close 释放由SDK维护的缓存和连接
	defer sdk.Close()

	err = sdkInit.CreateChannel(sdk, initInfo)
	if err != nil {
		fmt.Println(err.Error())
		return
	}

	//链码
	channelClient, err := sdkInit.InstallAndInstantiateCC(sdk, initInfo)
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	fmt.Println(channelClient)

	//测试服务
	serviceSetup := service.ServiceSetup{
		ChaincodeID: DataCC,
		Client:      channelClient,
	}

	// //测试用数据资源消费者对象
	// mem1 := service.Member{
	// 	ID:              "123",
	// 	IPAdress:        "1.1.1.1",
	// 	EndofMembership: "2021",
	// 	OrgName:         "org1",
	// }

	// //测试用数据资源提供者对象
	// mem2 := service.Member{
	// 	ID:              "121",
	// 	IPAdress:        "1.1.1.2",
	// 	EndofMembership: "2021",
	// 	OrgName:         "org2",
	// }

	//测试用数据文件对象
	file1 := service.DataFile{
		FileName:   "1.txt",
		ID:         "121",
		IPAdress:   "1.1.1.2",
		OrgName:    "org2",
		ModifyTime: "8:27 2019/9/12",
	}

	now := time.Now()
	// 测试用数据文件对象
	file2 := service.DataFile{
		FileName:   "1.txt",
		ID:         "121",
		IPAdress:   "1.1.1.2",
		OrgName:    "org2",
		ModifyTime: now.Format("15:04 2006/01/02"),
	}

	//测试用record对象
	record := service.Record{
		RecordNumber:     "1",
		CID:              "123",
		CIPAdress:        "1.1.1.1",
		CEndofMembership: "2021",
		COrgName:         "org1",
		Time:             "2020",
		Path:             "aaaaaaaa->baaaaaaa",
		FileName:         "1.txt",
		PID:              "121",
		PIPAdress:        "1.1.1.2",
		POrgName:         "org2",
		ModifyTime:       "8:27 2019/9/12",
	}

	//测试写入交易
	msg, err := serviceSetup.SaveRecord(record)
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("信息发布成功, 交易编号为: " + msg)
	}

	//测试根据记录编号查找交易
	result, err := serviceSetup.FindRecByRecNumber("1")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var rec service.Record
		json.Unmarshal(result, &rec)
		fmt.Println("根据记录编号查询信息成功：")
		fmt.Println(rec)
		fmt.Println([][]byte{[]byte("1")})

	}

	//测试根据提供者id查找交易
	result, err = serviceSetup.FindRecByProviderID("121")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var rec service.Record
		json.Unmarshal(result, &rec)
		fmt.Println("根据提供者id查询信息成功：")
		fmt.Println(rec)
	}

	//测试根据消费者id查找交易
	result, err = serviceSetup.FindRecByConsumerID("123")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var rec service.Record
		json.Unmarshal(result, &rec)
		fmt.Println("根据消费者id查询信息成功：")
		fmt.Println(rec)
	}

	//测试根据文件名查找交易
	result, err = serviceSetup.FindRecByFileName("1.txt")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var rec service.Record
		err = json.Unmarshal(result, &rec)
		fmt.Println("根据文件名查询信息成功：")
		fmt.Println(rec)
	}
	//交易记录链码测试结束

	//测试写入文件
	msg, err = serviceSetup.SaveFile(file1)
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("文件发布成功, 交易编号为: " + msg)
	}

	//测试根据文件名查找文件
	result, err = serviceSetup.FindFileByFileName("1.txt")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var file service.DataFile
		json.Unmarshal(result, &file)
		fmt.Println("根据文件名查询信息成功：")
		fmt.Println(file)
	}

	//测试根据提供者id查找交易
	result, err = serviceSetup.FindFileByProviderID("121")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var file service.DataFile
		json.Unmarshal(result, &file)
		fmt.Println("根据提供者id查询信息成功：")
		fmt.Println(file)
	}

	//测试删除文件
	result, err = serviceSetup.DeleteFile("1.txt")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("文件删除成功")
		fmt.Println(result)
	}
	result, err = serviceSetup.FindFileByFileName("1.txt")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var file service.DataFile
		json.Unmarshal(result, &file)
		fmt.Println("根据文件名查询信息成功：")
		fmt.Println(file)
	}

	//写入文件,供更新文件函数进行测试
	msg, err = serviceSetup.SaveFile(file1)
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("文件发布成功, 交易编号为: " + msg)
	}
	//测试更新文件
	msg, err = serviceSetup.UpdateFile(file2)
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("文件更新成功, 交易编号为: " + msg)
	}
	result, err = serviceSetup.FindFileByFileName("1.txt")
	if err != nil {
		fmt.Println(err.Error())
	} else {
		var file service.DataFile
		json.Unmarshal(result, &file)
		fmt.Println("根据文件名查询信息成功：")
		fmt.Println(file)
	}

	app := controller.Application{
		Setup: &serviceSetup,
	}
	web.WebStart(app)

}
